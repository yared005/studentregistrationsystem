package domain;

public enum Course {
    JAVA, PHP, HTML, MYSQL;
}
