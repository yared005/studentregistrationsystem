package domain;

public class Student {

    private String studentid;
    private String firstname;
    private String lastname;
    private String adress;
    private String phonenumber;
    private String email;
    public Course course;


    public Student(String studentid, String firstname, String lastname, String adress, String phonenumber, String email, Course course) {
        this.studentid = studentid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.adress = adress;
        this.phonenumber = phonenumber;
        this.email = email;
        this.course = course;
    }

    public String getstudentId() {

        return studentid;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getAddress() {
        return adress;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public String getEmail() {
        return email;
    }


    public Course getCourse() {
        return course;
    }
}
