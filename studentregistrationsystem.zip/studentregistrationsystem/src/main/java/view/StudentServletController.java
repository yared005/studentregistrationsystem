package view;

import domain.Course;
import domain.Student;
import exception.EntityNotFoundException;
import service.Service;
import service.StudentService;
import view.util.Message;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class StudentServletController extends BaseController {
    private Service<Student> service;

    public void init() {
        service = new StudentService();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException {
        doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException {
        try {
            String action = extractAction(request);

            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertStudent(request, response);
                    break;
                case "/delete":
                    deleteStudent(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateStudent(request, response);
                    break;
                default:

                    listStudent(request, response);
                    break;
            }
        } catch (ServletException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ServletException(ex);
        }

    }

    private String extractAction(HttpServletRequest request) {
        String pathInfo = request.getPathInfo();
        if (pathInfo == null) {
            return "list";
        } else {
            return pathInfo;
        }
    }

    private void listStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Student> listStudent = service.findAll();
        request.setAttribute("listStudent", listStudent);
        RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/Student/StudentList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request
                .getRequestDispatcher("/pages/Student/StudentForm.jsp");
        request.setAttribute("types", Course.values());
        request.setAttribute("isNew", true);
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            String studentid = request.getParameter("studentid");
            Student existingStrudent = service.findById(studentid);
            RequestDispatcher dispatcher = request
                    .getRequestDispatcher("/pages/student/StudentForm.jsp");
            request.setAttribute("types", Course.values());
            request.setAttribute("student", existingStrudent);
            request.setAttribute("isEdit", true);
            dispatcher.forward(request, response);
        } catch (EntityNotFoundException e) {
            request.setAttribute("message", e.getMessage());
            listStudent(request, response);
        }

    }

    private void insertStudent(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Student student = null;


        try {
            String studentid = UUID.randomUUID().toString();
            String firstname = request.getParameter("firstname");
            String lastname = request.getParameter("lastname");
            String address = request.getParameter("address");
            String phonenumber = request.getParameter("phonenumber");
            String email = request.getParameter("email");
             String course = String.valueOf(request.getParameter("course"));

            student = new Student(studentid, firstname, lastname, address, email, phonenumber, course);

            service.add(student);
            request.setAttribute("message", Message.buildSuccessMessage("Student added successfully"));
            listStudent(request, response);
        } catch (Exception e) {
            request.setAttribute("student", student);
            request.setAttribute("message", processException(e));
            request.setAttribute("isNew", true);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/Student/StudentForm.jsp");
            dispatcher.forward(request, response);
        }
    }

    private void updateStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Student student = null;
        try {
            String studentid = request.getParameter("studentid");
            String firstname = request.getParameter("firstname");
            String lastname = request.getParameter("lastname");
            String address = request.getParameter("address");
            String phonenumber = request.getParameter("phonenumber");
            String email = request.getParameter("email");
            String course = String.valueOf(request.getParameter("course"));

            student = new Student(studentid, firstname, lastname, address, email, phonenumber, course);

            service.modify(student);
            request.setAttribute("message", Message.buildSuccessMessage("Student updated successfully"));
            listStudent(request, response);
        } catch (Exception e) {
            request.setAttribute("student", student);
            request.setAttribute("message", processException(e));
            request.setAttribute("isEdit", true);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/pages/Student/StudentForm.jsp");
            dispatcher.forward(request, response);
        }
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            String studentid = request.getParameter("studentid");
            service.remove(studentid);
            request.setAttribute("message", Message.buildSuccessMessage("Student deleted successfully"));
            listStudent(request, response);
        } catch (Exception e) {
            request.setAttribute("message", processException(e));
            listStudent(request, response);
        }

    }
}
