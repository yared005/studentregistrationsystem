package service;

import com.google.common.annotations.VisibleForTesting;
import domain.Student;
import exception.EntityNotFoundException;
import repository.Repository;
import repository.StudentRepository;

import java.util.List;

public class StudentService implements Service<Student> {



    private Repository<Student> studentRepository;

    public StudentService() {
        studentRepository = new StudentRepository();
    }

    public StudentService(Repository<Student> studentRepository) {
        this.studentRepository = studentRepository;
    }

    //@VisibleForTesting
//    void validate(Student student) {
//        if (student.getstudentId() < MAX_YEAR_ALLOWED) {
//            throw new ValidationException("The car cannot be older than year 2000");
//        }
//
//        if (isDuplicatedPlate(student)) {
//            throw new ValidationException("There is another car with the same plate, please, choose another one");
//        }
//    }

    @VisibleForTesting
    boolean isDuplicatedstudentid(Student student) {
        return studentRepository
                .findByCriteria("studentid", student.getstudentId())
                .filter(c -> !c.getstudentId().equals(student.getstudentId()))
                .isPresent();
    }

    public void add(Student student) {
        //validate(student);
        studentRepository.add(student);
    }

    public void modify(Student student) {
        studentRepository
                .findById(student.getstudentId())
                .orElseThrow(
                        () -> new EntityNotFoundException("Student with id " + student.getstudentId() + " was not found!"));

       // validate(student);
        studentRepository.modify(student);
    }

    public void remove(String studentid) {
        studentRepository.remove(studentRepository
                                     .findById(studentid)
                                     .orElseThrow(
                                             () -> new EntityNotFoundException("Student with id " + studentid + " was not found!"))
        );
    }

    public Student findById(String studentid) {
        return studentRepository.findById(studentid).orElseThrow(() -> new EntityNotFoundException("Student with id " + studentid + " was not found!"));
    }

    public List<Student> findAll() {
        return studentRepository.findAll();
    }
}
